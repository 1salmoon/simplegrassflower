# SimpleGrassFlower

Standalone native mod for [LeviLauncher](https://github.com/LiteLDev/LeviLaunchroid) (Minecraft Bedrock,
Android arm64). Mimics Java "flowery grass" packs such as *Simple Grass Flowers*.

> Status: experimental. Signatures/offsets are version specific.

## How it works

- **Rock, small flower, big flower** are transparent overlays. The terrain layer has no alpha test, so the mod
  captures the overlay quad (not drawn) and emits one small opaque quad per run of opaque pixels, sampling exactly
  those texels, `overlayLift` above the grass, vertex colors neutralized so biome tint does not apply. Masks live in
  `src/decor_masks.hpp`.

Variant per block comes from a position hash with the Java weights (rock 7, small flower 27, big flower 14 out of 1000).
Clover support has been removed.

## Resource pack

Use `SimpleGrassFlower_RP_1.0.0.mcpack` (personal use only: the Java pack is CC BY-NC-ND 4.0). `grass_top` must be a
plain list in this order. Do NOT convert it to weighted `variations`: the game then ignores the variant index and no
flowers appear.

| Index | Texture |
|---|---|
| 0 | `grass_top` |
| 1 | `grass_block/grass_block_top_clover` (not used by the mod yet) |
| 2 | `grass_block/grass_block_top_clover_small` (not used by the mod yet) |
| 3 | `grass_block/rock` |
| 4 | `grass_block/flower_small` |
| 5 | `grass_block/flower_big` |

If the mod logs `grass_top has no decoration variants` (logcat tag `SimpleGrassFlower`), no decorations are drawn.

## Biome flower variants

Small and big flowers switch texture in swamp/mangrove swamp, pale garden and cherry grove, like the Java pack's
CTM rules. Rock is unchanged. The `sgf_decor` list in the resource pack gets indices 6-11:

| Index | Texture |
|---|---|
| 6 / 7 | `flower_small_swamp` / `flower_big_swamp` |
| 8 / 9 | `flower_small_pale` / `flower_big_pale` |
| 10 / 11 | `flower_small_sakura` / `flower_big_sakura` |

The biome is guessed from the biome tint baked into the overlay quad's vertex color (ratios r/g and b/g, nearest
reference color, `kTintRefs` in `main.cpp`). If a biome picks the wrong variant, set `logBiomeTint` to `true`, stand
in that biome, read the `tint r/g=... b/g=...` lines in logcat (tag `SimpleGrassFlower`) and adjust `kTintRefs`
or `biomeTolerance`.

## Config

`config.json` in the mod's config directory (created on first run, reloaded about every 2 seconds in game):

```json
{
  "removeTopTint": false,
  "flipMask": false,
  "decorBrightness": 1.25,
  "decorChance": 1.0,
  "overlayLift": 0.02,
  "biomeVariants": true,
  "biomeTolerance": 0.04,
  "logBiomeTint": false
}
```

- `removeTopTint`: also remove biome tint from the grass top itself.
- `flipMask`: set `true` if flowers/rocks look mirrored or have stray pixels.
- `decorBrightness`: brightness of the neutralized overlay (0.25 to 2.0).
- `decorChance`: multiplier for how many blocks get rock/flowers (0 disables).
- `biomeVariants`: per-biome flower textures (`false` = always the base flowers).
- `biomeTolerance`: how close a tint must be to a reference color (0.005 to 0.3).
- `logBiomeTint`: log tints seen on flowers, to calibrate the references.
- `overlayLift`: height of overlay quads above the grass (0.002 to 0.1). Raise it if flowers flicker or sink in.

## Known limits

- Nylium/podzol/mycelium variants are not implemented.
- Biome variants are detected from the grass tint, not the real biome (see below), so transitions between biomes can pick the wrong variant.
- `src/decor_masks.hpp` encodes the silhouettes of the Java pack's rock and flower textures. Keep the repository private.
- Offsets and signatures target the same build as BedrockTools 1.5.12 (`1.26.6X.X`).

## Build

Requirements: Android NDK r28c, xmake, Python 3 (or use the included GitHub Actions workflow).

```sh
xmake f -y -p android -a arm64-v8a -m release --ndk=/path/to/android-ndk-r28c
xmake -y
```

## Credits

Signatures, offsets and hook approach from [BedrockTools](https://github.com/QYCottage/BedrockTools) (MIT).
Decoration idea and weights from the *Simple Grass Flowers* Java pack by 2DWisp, Bedrock port by PointyFour66164
(not included).
