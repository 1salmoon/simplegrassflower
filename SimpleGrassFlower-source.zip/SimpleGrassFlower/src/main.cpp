// SimpleGrassFlower - standalone LeviLauncher native mod for Minecraft Bedrock (Android arm64).
//
// Mimics Java "flowery grass" packs: rocks and flowers are drawn as untinted overlay quads on top
// of the grass. (Clover support has been removed.)
//
// The resource pack's grass_top must be a PLAIN texture list (not weighted `variations`, the game then
// ignores the variant index) laid out as:
//   index 0 = vanilla grass top, 1-2 = unused placeholders (plain grass_top), 3 = rock,
//   4 = flower small, 5 = flower big
// (see README.md). The mod asks the game for the texture of the Up face with variant 3..5.
//
// Signatures and offsets are version specific and were taken from BedrockTools (MIT).

#include "decor_masks.hpp"

#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include <android/log.h>
#include <sys/stat.h>

#include <algorithm>
#include <iterator>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

namespace {

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SimpleGrassFlower", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "SimpleGrassFlower", __VA_ARGS__)

// ---- Version specific data (update per Minecraft build) ------------------------------

constexpr const char* kLibrary = "libminecraftpe.so";

constexpr const char* kSigVertex         = "? ? ? D1 ? ? ? FD ? ? ? 6D ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 5B D0 3B D5 ? ? ? F9 ? ? ? F9";
constexpr const char* kSigUseNewTess     = "? ? ? A9 ? ? ? A9 FD 03 00 91 F4 03 01 2A F3 03 00 AA ? ? ? ? ? ? ? 36 ? ? ? 36";
constexpr const char* kSigChunkBuild     = "? ? ? FC ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 ? ? ? D1 ? ? ? B9 48 D0 3B D5 F3 03 05 AA";
constexpr const char* kSigGraphicsForBlk = "? ? ? A9 ? ? ? F9 FD 03 00 91 F3 03 00 AA ? ? ? ? ? ? ? B4 ? ? ? F9 ? ? ? A8 C0 03 5F D6 E0 03 13 AA ? ? ? ? ? ? ? 36 E0 03 13 AA";
constexpr const char* kSigSetAllDirty    = "? ? ? D1 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 48 D0 3B D5 F4 03 02 2A F3 03 00 AA";
constexpr const char* kSigClientUpdate   = "? ? ? FC ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 ? ? ? D1 59 D0 3B D5 ? ? ? 52 F5 03 02 2A";
constexpr const char* kSigFaceUp         = "? ? ? D1 ? ? ? 6D ? ? ? 6D ? ? ? 6D ? ? ? 6D ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 57 D0 3B D5 ? ? ? 91 F6 03 03 AA ? ? ? F9 F5 03 02 AA F4 03 00 AA F3 03 01 AA ? ? ? F8 ? ? ? 39 ? ? ? 39 1F 01 00 71 98 00 8A 9A ? ? ? 37 ? ? ? 39 ? ? ? 34 ? ? ? F9 ? ? ? B4 ? ? ? F9 ? ? ? 91 ? ? ? 91 ? ? ? ? ? ? ? ? ? ? ? F9 ? ? ? 91 ? ? ? ? ? ? ? F9 ? ? ? 3D ? ? ? F9 ? ? ? 52 ? ? ? 3D ? ? ? 39 E0 03 13 AA ? ? ? 52";
constexpr const char* kSigGetTexture     = "? ? ? D1 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 54 D0 3B D5 ? ? ? D2 F3 03 01 AA";

constexpr std::size_t kOffNextColor     = 0x1B0;  // Tessellator::mNextColor
constexpr std::size_t kOffNextColorSet  = 0x1B4;  // Tessellator::mNextColorSet
constexpr std::size_t kOffBlockShape    = 0x10;   // BlockGraphics::mBlockShape
constexpr std::size_t kOffBlockType     = 0x68;   // Block::mBlockType
constexpr std::size_t kOffNameInfo      = 0x88;   // BlockType::mNameInfo
constexpr std::size_t kOffFullName      = 0x40;   // NameInfo::mFullName
constexpr std::size_t kOffHashedString  = 0x8;    // HashedString::mString
constexpr std::size_t kOffUvU0          = 0x4;    // TextureUVCoordinateSet::mU0
constexpr std::size_t kOffUvV0          = 0x8;    // TextureUVCoordinateSet::mV0
constexpr std::size_t kOffUvU1          = 0xC;    // TextureUVCoordinateSet::mU1
constexpr std::size_t kOffUvV1          = 0x10;   // TextureUVCoordinateSet::mV1
constexpr std::size_t kOffTextureU      = 0x18C;  // Tessellator::mTextureU
constexpr std::size_t kOffTextureV      = 0x190;  // Tessellator::mTextureV
constexpr std::size_t kOffLevelRenderer = 0x1B8;  // ClientInstance::mLevelRenderer
constexpr std::size_t kOffCoordinators  = 0x28;   // LevelRenderer::mRenderChunkCoordinators
constexpr std::size_t kOffFirstNode     = 0x10;   // HashTable::mFirstNode
constexpr std::size_t kOffNodeNext      = 0x0;    // HashNode::mNext
constexpr std::size_t kOffNodeValue     = 0x18;   // HashNode::mValuePointer
constexpr std::size_t kMaxNodes         = 64;
constexpr std::size_t kFaceUp           = 1;      // Down=0, Up=1, North=2, South=3, West=4, East=5
constexpr std::size_t kFaceDecor        = 0;      // Down face of grass block carries the decoration variants (texture 'sgf_decor')

// Decoration variants. Index = texture variant requested from the game.
// Weights are the Java pack's blockstate weights out of 1000: rock 7, flower_small 27, flower_big 14.
// Variants 1 and 2 (formerly clover) are intentionally never picked.
struct Decor { int variant; int weight; };
constexpr Decor kDecor[] = {{3, 7}, {4, 27}, {5, 14}};
constexpr int kTotalWeight = 1000;

// Biome variants of the flowers (Java: OptiFine CTM swamp / pale garden / cherry grove).
// sgf_decor indices 6..11: swamp small/big, pale small/big, sakura small/big.
// Rock keeps its texture everywhere, like the Java pack. Index = 6 + (biome - 1) * 2 + (variant - 4).
constexpr int kBiomeVariantBase = 6;

// ---- Types ---------------------------------------------------------------------------

struct Vec3 { float x, y, z; };
struct BlockPos { std::int32_t x, y, z; };

using FaceFn             = void (*)(void*, void*, const void*, const Vec3*, const void*);
using VertexFn           = void (*)(void*, float, float, float);
using UseNewTessFn       = bool (*)(const void*, bool);
using GraphicsForBlockFn = const void* (*)(const void*);
using GetTextureFn       = const void* (*)(const void*, const BlockPos*, std::size_t, std::uint32_t);
using ChunkBuildFn       = void (*)(void*, void*, bool, std::int32_t, bool, const void*);
using SetAllDirtyFn      = void (*)(void*, bool, bool);
using ClientUpdateFn     = void* (*)(void*, bool);

template <class T>
T& field(void* object, std::size_t offset) {
    return *reinterpret_cast<T*>(reinterpret_cast<std::uintptr_t>(object) + offset);
}
template <class T>
const T& field(const void* object, std::size_t offset) {
    return *reinterpret_cast<const T*>(reinterpret_cast<std::uintptr_t>(object) + offset);
}

// ---- State ---------------------------------------------------------------------------

FaceFn             g_faceUpOrig = nullptr;
VertexFn           g_vertexOrig = nullptr;
UseNewTessFn       g_useNewTessOrig = nullptr;
GraphicsForBlockFn g_graphicsForBlock = nullptr;
GetTextureFn       g_getTexture = nullptr;
ChunkBuildFn       g_chunkBuildOrig = nullptr;
SetAllDirtyFn      g_setAllDirty = nullptr;
ClientUpdateFn     g_clientUpdateOrig = nullptr;

std::atomic_bool   g_active{false};
std::atomic_bool   g_flipMask{false};             // flip the opaque-pixel mask vertically
std::atomic_bool   g_removeTopTint{false};        // also remove biome tint from the grass top itself
std::atomic<float> g_decorBrightness{1.25f};
std::atomic<float> g_decorScale{1.0f};            // multiplies decoration chance
std::atomic<float> g_overlayLift{0.02f};          // height of overlay quads above the grass top (anti z-fight)
std::atomic_bool   g_rebuildPending{false};
std::atomic_bool   g_decorWarned{false};
std::atomic_bool   g_biomeVariants{true};         // swap flower textures per biome (detected from the grass tint)
std::atomic<float> g_biomeTolerance{0.04f};       // max tint distance to a reference color
std::atomic_bool   g_logTint{false};              // log grass tints seen on flowers, to calibrate the references

thread_local bool  g_insideTerrainBuild = false;
struct Capture {
    void*         mesh = nullptr;
    int           count = 0;
    float         x[8]{}, y[8]{}, z[8]{}, u[8]{}, v[8]{};
    std::uint32_t color = 0;
};
thread_local Capture* g_capture = nullptr;        // while set, vertices of `mesh` are recorded, not emitted
thread_local void* g_untintMesh = nullptr;        // mesh tessellator whose vertex colors are neutralized

std::filesystem::path  g_configPath;
std::atomic<long long> g_configMtime{0};
std::atomic<int>       g_updateCounter{0};

bool       g_hooksInstalled = false;
std::mutex g_installMutex;

// ---- Config --------------------------------------------------------------------------

long long configMtime() {
    struct stat info {};
    if (g_configPath.empty() || stat(g_configPath.c_str(), &info) != 0) return 0;
    return static_cast<long long>(info.st_mtime);
}

bool readValue(const std::string& text, const char* key, std::string& out) {
    const std::string needle = std::string("\"") + key + "\"";
    const auto at = text.find(needle);
    if (at == std::string::npos) return false;
    const auto colon = text.find(':', at);
    if (colon == std::string::npos) return false;
    auto begin = text.find_first_not_of(" \t\r\n", colon + 1);
    if (begin == std::string::npos) return false;
    auto end = text.find_first_of(",}\r\n", begin);
    out = text.substr(begin, end == std::string::npos ? std::string::npos : end - begin);
    return true;
}

void loadConfig() {
    if (g_configPath.empty()) return;
    std::error_code ec;
    if (!std::filesystem::exists(g_configPath, ec)) {
        std::filesystem::create_directories(g_configPath.parent_path(), ec);
        std::ofstream out(g_configPath);
        out << "{\n"
               "  \"removeTopTint\": false,\n"
               "  \"flipMask\": false,\n"
               "  \"decorBrightness\": 1.25,\n"
               "  \"decorChance\": 1.0,\n"
               "  \"overlayLift\": 0.02,\n"
               "  \"biomeVariants\": true,\n"
               "  \"biomeTolerance\": 0.04,\n"
               "  \"logBiomeTint\": false\n"
               "}\n";
    } else {
        std::ifstream in(g_configPath);
        std::stringstream buffer;
        buffer << in.rdbuf();
        const std::string text = buffer.str();
        std::string value;
        if (readValue(text, "removeTopTint", value)) g_removeTopTint.store(value.rfind("true", 0) == 0);
        if (readValue(text, "flipMask", value)) g_flipMask.store(value.rfind("true", 0) == 0);
        if (readValue(text, "decorBrightness", value)) {
            g_decorBrightness.store(std::clamp(static_cast<float>(std::atof(value.c_str())), 0.25f, 2.0f));
        }
        if (readValue(text, "decorChance", value)) {
            g_decorScale.store(std::clamp(static_cast<float>(std::atof(value.c_str())), 0.0f, 5.0f));
        }
        if (readValue(text, "biomeVariants", value)) g_biomeVariants.store(value.rfind("true", 0) == 0);
        if (readValue(text, "logBiomeTint", value)) g_logTint.store(value.rfind("true", 0) == 0);
        if (readValue(text, "biomeTolerance", value)) {
            g_biomeTolerance.store(std::clamp(static_cast<float>(std::atof(value.c_str())), 0.005f, 0.3f));
        }
        if (readValue(text, "overlayLift", value)) {
            g_overlayLift.store(std::clamp(static_cast<float>(std::atof(value.c_str())), 0.002f, 0.1f));
        }
    }
    g_configMtime.store(configMtime(), std::memory_order_relaxed);
}

// ---- Grass logic ---------------------------------------------------------------------

bool nameIsGrass(const void* block) {
    const auto type = reinterpret_cast<std::uintptr_t>(field<void*>(block, kOffBlockType));
    if (!type) return false;
    const auto* name = reinterpret_cast<const std::string*>(type + kOffNameInfo + kOffFullName + kOffHashedString);
    if (!name || name->size() > 64) return false;
    return *name == "minecraft:grass_block" || *name == "minecraft:grass";
}

// Block objects are stable, so the string compare is cached per thread.
bool isGrassBlock(const void* block) {
    if (!block) return false;
    thread_local std::unordered_map<const void*, bool> cache;
    const auto it = cache.find(block);
    if (it != cache.end()) return it->second;
    const bool grass = nameIsGrass(block);
    cache.emplace(block, grass);
    return grass;
}

std::uint32_t hashPosition(std::int32_t x, std::int32_t y, std::int32_t z) {
    std::uint64_t h = static_cast<std::uint64_t>(static_cast<std::uint32_t>(x)) * 0x9E3779B97F4A7C15ull;
    h ^= static_cast<std::uint64_t>(static_cast<std::uint32_t>(z)) * 0xC2B2AE3D27D4EB4Full + (h << 6) + (h >> 2);
    h ^= static_cast<std::uint64_t>(static_cast<std::uint32_t>(y)) * 0x165667B19E3779F9ull + (h << 6) + (h >> 2);
    h ^= h >> 33; h *= 0xFF51AFD7ED558CCDull; h ^= h >> 33; h *= 0xC4CEB9FE1A85EC53ull; h ^= h >> 33;
    return static_cast<std::uint32_t>(h);
}

// Variants 3..5 (rock, flowers) are transparent overlays that must not be tinted.

// Returns 0 for no decoration, otherwise the texture variant 3..5.
// Integer weights are scaled x100.
int pickDecor(const BlockPos& pos) {
    const float scale = g_decorScale.load(std::memory_order_relaxed);
    int weights[std::size(kDecor)];
    int decorTotal = 0;
    for (std::size_t i = 0; i < std::size(kDecor); ++i) {
        weights[i] = std::max(0, static_cast<int>(static_cast<float>(kDecor[i].weight) * scale * 100.0f));
        decorTotal += weights[i];
    }
    if (decorTotal <= 0) return 0;
    const int space = std::max(kTotalWeight * 100, decorTotal);
    int roll = static_cast<int>(hashPosition(pos.x, pos.y, pos.z) % static_cast<std::uint32_t>(space));
    if (roll >= decorTotal) return 0;
    for (std::size_t i = 0; i < std::size(kDecor); ++i) {
        if (roll < weights[i]) return kDecor[i].variant;
        roll -= weights[i];
    }
    return 0;
}

// Biome tint multiplies the vertex color, so tinted vertices have unequal RGB.
// Untinted shade colors are already gray (r == g == b) and are left alone.
std::uint32_t neutralize(std::uint32_t packed) {
    const std::uint32_t r = packed & 0xFFu;
    const std::uint32_t g = (packed >> 8) & 0xFFu;
    const std::uint32_t b = (packed >> 16) & 0xFFu;
    if (r == g && g == b) return packed;
    const float peak = static_cast<float>(std::max({r, g, b})) * g_decorBrightness.load(std::memory_order_relaxed);
    const auto v = static_cast<std::uint32_t>(std::clamp(std::lround(peak), 0l, 255l));
    return (packed & 0xFF000000u) | (v << 16) | (v << 8) | v;
}

class UntintScope {
public:
    UntintScope(void* mesh) : m_previous(g_untintMesh) { g_untintMesh = mesh; }
    ~UntintScope() { g_untintMesh = m_previous; }
private:
    void* m_previous;
};

// ---- Detours -------------------------------------------------------------------------

// Biome detection without BlockSource: the game bakes the biome grass tint into the vertex color of
// the (captured) overlay quad. Shading scales r, g, b equally, so the ratios r/g and b/g identify
// the tint. The nearest reference decides; non-decor biomes are listed so they win their own area.
// biome ids: 0 = none, 1 = swamp, 2 = pale garden, 3 = cherry grove.
struct TintRef { int r, g, b, biome; };
constexpr TintRef kTintRefs[] = {
    {0x6A, 0x70, 0x39, 1},  // swamp, mangrove swamp
    {0x77, 0x82, 0x72, 2},  // pale garden
    {0xB6, 0xDB, 0x61, 3},  // cherry grove
    {0x91, 0xBD, 0x59, 0},  // plains
    {0x79, 0xC0, 0x5A, 0},  // forest, default
    {0x88, 0xBB, 0x67, 0},  // birch forest
    {0x83, 0xBB, 0x6D, 0},  // meadow
    {0x86, 0xB7, 0x83, 0},  // taiga
    {0x80, 0xB4, 0x97, 0},  // snowy
    {0x8A, 0xB6, 0x89, 0},  // windswept
    {0xBF, 0xB7, 0x55, 0},  // savanna, desert
    {0x59, 0xC9, 0x3C, 0},  // jungle
    {0x90, 0x81, 0x4D, 0},  // badlands
};

int classifyBiome(std::uint32_t packed) {
    const float r = static_cast<float>(packed & 0xFFu);
    const float g = static_cast<float>((packed >> 8) & 0xFFu);
    const float b = static_cast<float>((packed >> 16) & 0xFFu);
    if (g < 24.0f || (r == g && g == b)) return 0;  // too dark to tell, or untinted
    const float x = r / g, y = b / g;
    float best = 1e9f;
    int biome = 0;
    for (const TintRef& ref : kTintRefs) {
        const float dx = x - static_cast<float>(ref.r) / static_cast<float>(ref.g);
        const float dy = y - static_cast<float>(ref.b) / static_cast<float>(ref.g);
        const float d = std::sqrt(dx * dx + dy * dy);
        if (d < best) { best = d; biome = ref.biome; }
    }
    if (g_logTint.load(std::memory_order_relaxed)) {
        static std::mutex logMutex;
        static std::vector<int> seen;
        const int key = static_cast<int>(x * 100.0f) * 1000 + static_cast<int>(y * 100.0f);
        std::lock_guard lock(logMutex);
        if (seen.size() < 128 && std::find(seen.begin(), seen.end(), key) == seen.end()) {
            seen.push_back(key);
            LOGI("tint r/g=%.3f b/g=%.3f nearest_biome=%d dist=%.3f", x, y, biome, best);
        }
    }
    return best <= g_biomeTolerance.load(std::memory_order_relaxed) ? biome : 0;
}

const std::uint16_t* maskFor(int variant) {
    switch (variant) {
        case 3: return decor::kMaskRock;
        case 4: return decor::kMaskFlowerSmall;
        case 5: return decor::kMaskFlowerBig;
        default: return nullptr;
    }
}

class CaptureScope {
public:
    explicit CaptureScope(Capture* capture) : m_previous(g_capture) { g_capture = capture; }
    ~CaptureScope() { g_capture = m_previous; }
private:
    Capture* m_previous;
};

// The overlay textures are transparent but the terrain layer has no alpha test, so transparent
// pixels would render as opaque squares. Instead the overlay quad is captured (not drawn) and
// one small opaque quad per run of opaque pixels is emitted, sampling exactly those texels.
void emitOverlay(void* blockTessellator, void* meshTessellator, const void* block,
                 const Vec3* position, const void* decor, int variant,
                 const void* graphics, const BlockPos& pos) {
    const std::uint16_t* rows = maskFor(variant);
    if (!rows || !g_vertexOrig) return;

    const Vec3 raised{position->x, position->y + g_overlayLift.load(std::memory_order_relaxed), position->z};
    Capture cap;
    cap.mesh = meshTessellator;
    {
        CaptureScope scope(&cap);
        g_faceUpOrig(blockTessellator, meshTessellator, block, &raised, decor);
    }
    if (cap.count != 4) {
        static std::atomic_bool warned{false};
        if (!warned.exchange(true)) LOGW("overlay face emitted %d vertices, expected 4", cap.count);
        return;
    }

    const float u0 = field<float>(decor, kOffUvU0), v0 = field<float>(decor, kOffUvV0);
    const float u1 = field<float>(decor, kOffUvU1), v1 = field<float>(decor, kOffUvV1);
    if (u1 == u0 || v1 == v0) return;

    // Which texture corner (a, b in {0, 1}) each recorded vertex sits on.
    int ca[4], cb[4];
    for (int i = 0; i < 4; ++i) {
        ca[i] = (cap.u[i] - u0) / (u1 - u0) > 0.5f ? 1 : 0;
        cb[i] = (cap.v[i] - v0) / (v1 - v0) > 0.5f ? 1 : 0;
    }
    for (int i = 0; i < 4; ++i) {
        for (int j = i + 1; j < 4; ++j) {
            if (ca[i] == ca[j] && cb[i] == cb[j]) {
                static std::atomic_bool warned{false};
                if (!warned.exchange(true)) LOGW("overlay face has degenerate texture corners");
                return;
            }
        }
    }

    // Rect to sample. Biome flower variants have the same silhouette as the base flower (the masks
    // are identical), so only the sampled atlas rect changes.
    float su0 = u0, sv0 = v0, su1 = u1, sv1 = v1;
    if ((variant == 4 || variant == 5) && g_biomeVariants.load(std::memory_order_relaxed)) {
        const int biome = classifyBiome(cap.color);
        if (biome > 0) {
            const std::uint32_t index = static_cast<std::uint32_t>(kBiomeVariantBase + (biome - 1) * 2 + (variant - 4));
            const void* base = g_getTexture(graphics, &pos, kFaceDecor, 0);
            const void* biomeTex = g_getTexture(graphics, &pos, kFaceDecor, index);
            if (base && biomeTex && biomeTex != base
                && (field<float>(biomeTex, kOffUvU0) != field<float>(base, kOffUvU0)
                    || field<float>(biomeTex, kOffUvV0) != field<float>(base, kOffUvV0))) {
                su0 = field<float>(biomeTex, kOffUvU0); sv0 = field<float>(biomeTex, kOffUvV0);
                su1 = field<float>(biomeTex, kOffUvU1); sv1 = field<float>(biomeTex, kOffUvV1);
            } else {
                static std::atomic_bool warned{false};
                if (!warned.exchange(true)) LOGW("biome flower variants missing in sgf_decor; update the resource pack");
            }
        }
    }

    auto& packed = field<std::uint32_t>(meshTessellator, kOffNextColor);
    auto& colorSet = field<std::uint8_t>(meshTessellator, kOffNextColorSet);
    auto& texU = field<float>(meshTessellator, kOffTextureU);
    auto& texV = field<float>(meshTessellator, kOffTextureV);
    const std::uint32_t savedColor = packed;
    const std::uint8_t savedSet = colorSet;
    packed = neutralize(cap.color);
    colorSet = 1;

    const bool flip = g_flipMask.load(std::memory_order_relaxed);
    constexpr float kInset = 0.02f / 16.0f;  // keep samples inside the texel
    for (int row = 0; row < 16; ++row) {
        const std::uint16_t bits = rows[row];
        int x = 0;
        while (x < 16) {
            if (!(bits & (1u << x))) { ++x; continue; }
            int end = x;
            while (end < 16 && (bits & (1u << end))) ++end;

            const float aMin = static_cast<float>(x) / 16.0f, aMax = static_cast<float>(end) / 16.0f;
            float bMin = static_cast<float>(row) / 16.0f, bMax = static_cast<float>(row + 1) / 16.0f;
            if (flip) { const float t = 1.0f - bMax; bMax = 1.0f - bMin; bMin = t; }

            for (int i = 0; i < 4; ++i) {
                const float a = ca[i] ? aMax : aMin;
                const float b = cb[i] ? bMax : bMin;
                float px = 0, py = 0, pz = 0;
                for (int j = 0; j < 4; ++j) {
                    const float w = (ca[j] ? a : 1.0f - a) * (cb[j] ? b : 1.0f - b);
                    px += w * cap.x[j]; py += w * cap.y[j]; pz += w * cap.z[j];
                }
                const float au = ca[i] ? aMax - kInset : aMin + kInset;
                const float bv = cb[i] ? bMax - kInset : bMin + kInset;
                texU = su0 + au * (su1 - su0);
                texV = sv0 + bv * (sv1 - sv0);
                g_vertexOrig(meshTessellator, px, py, pz);
            }
            x = end;
        }
    }
    packed = savedColor;
    colorSet = savedSet;
}

void faceUpDetour(void* blockTessellator, void* meshTessellator, const void* block,
                  const Vec3* position, const void* texture) {
    if (!g_faceUpOrig) return;
    if (!g_active.load(std::memory_order_relaxed) || !g_insideTerrainBuild || !block || !position
        || !meshTessellator || !g_getTexture || !g_graphicsForBlock || !isGrassBlock(block)) {
        g_faceUpOrig(blockTessellator, meshTessellator, block, position, texture);
        return;
    }

    // Pick a decoration variant for this block and look up its texture in the atlas.
    const BlockPos pos{static_cast<std::int32_t>(std::floor(position->x)),
                       static_cast<std::int32_t>(std::floor(position->y)),
                       static_cast<std::int32_t>(std::floor(position->z))};
    const int variant = pickDecor(pos);
    const void* decor = nullptr;
    const void* graphics = nullptr;
    if (variant != 0) {
        if ((graphics = g_graphicsForBlock(block)) != nullptr) {
            const void* base = g_getTexture(graphics, &pos, kFaceDecor, 0);
            const void* candidate = g_getTexture(graphics, &pos, kFaceDecor, static_cast<std::uint32_t>(variant));
            if (base && candidate && candidate != base
                && (field<float>(candidate, kOffUvU0) != field<float>(base, kOffUvU0)
                    || field<float>(candidate, kOffUvV0) != field<float>(base, kOffUvV0))) {
                decor = candidate;
            } else if (!g_decorWarned.exchange(true)) {
                LOGW("grass_top has no decoration variants; resource pack missing or variants ignored");
            }
        }
    }

    // 1. The grass top (always the vanilla/base texture).
    const void* topTexture = texture;
    if (g_removeTopTint.load(std::memory_order_relaxed)) {
        UntintScope scope(meshTessellator);
        g_faceUpOrig(blockTessellator, meshTessellator, block, position, topTexture);
    } else {
        g_faceUpOrig(blockTessellator, meshTessellator, block, position, topTexture);
    }

    // 2. Rock and flowers are transparent overlays drawn slightly above the top, without tint.
    if (decor) emitOverlay(blockTessellator, meshTessellator, block, position, decor, variant, graphics, pos);
}

void vertexDetour(void* tessellator, float x, float y, float z) {
    if (!g_vertexOrig) return;
    if (g_capture && tessellator && g_capture->mesh == tessellator) {
        Capture& c = *g_capture;
        if (c.count < 8) {
            if (c.count == 0) c.color = field<std::uint32_t>(tessellator, kOffNextColor);
            c.x[c.count] = x; c.y[c.count] = y; c.z[c.count] = z;
            c.u[c.count] = field<float>(tessellator, kOffTextureU);
            c.v[c.count] = field<float>(tessellator, kOffTextureV);
        }
        ++c.count;
        return;
    }
    if (!tessellator || g_untintMesh != tessellator
        || field<std::uint8_t>(tessellator, kOffNextColorSet) == 0) {
        g_vertexOrig(tessellator, x, y, z);
        return;
    }
    auto& packed = field<std::uint32_t>(tessellator, kOffNextColor);
    const std::uint32_t original = packed;
    packed = neutralize(original);
    g_vertexOrig(tessellator, x, y, z);
    packed = original;
}

// Grass is a plain cube and normally goes through the new mesh path, which never calls the
// per-face functions. Returning false selects the legacy path that the face hook sees.
bool useNewTessellationDetour(const void* block, bool onlyNew) {
    if (!g_useNewTessOrig) return onlyNew;
    const bool native = g_useNewTessOrig(block, onlyNew);
    if (!native || !block || !g_insideTerrainBuild || !g_graphicsForBlock
        || !g_active.load(std::memory_order_acquire) || !isGrassBlock(block)) return native;
    const void* graphics = g_graphicsForBlock(block);
    if (!graphics) return native;
    const auto shape = field<std::uint32_t>(graphics, kOffBlockShape);
    const bool cube = shape == 0 || shape == 67 || shape == 93 || shape == 117;
    return cube ? false : native;
}

void chunkBuildDetour(void* builder, void* geometry, bool transparentLeaves, std::int32_t lightingType,
                      bool forExport, const void* lightingCaps) {
    if (!g_chunkBuildOrig) return;
    if (!g_active.load(std::memory_order_relaxed) || forExport) {
        g_chunkBuildOrig(builder, geometry, transparentLeaves, lightingType, forExport, lightingCaps);
        return;
    }
    const bool previous = g_insideTerrainBuild;
    g_insideTerrainBuild = true;
    g_chunkBuildOrig(builder, geometry, transparentLeaves, lightingType, forExport, lightingCaps);
    g_insideTerrainBuild = previous;
}

bool rebuildChunks(void* clientInstance) {
    if (!clientInstance || !g_setAllDirty) return false;
    void* levelRenderer = field<void*>(clientInstance, kOffLevelRenderer);
    if (!levelRenderer) return false;
    void* node = field<void*>(levelRenderer, kOffCoordinators + kOffFirstNode);
    bool rebuilt = false;
    std::size_t visited = 0;
    while (node && visited++ < kMaxNodes) {
        void* next = field<void*>(node, kOffNodeNext);
        void* coordinator = field<void*>(node, kOffNodeValue);
        if (coordinator) {
            g_setAllDirty(coordinator, true, false);
            rebuilt = true;
        }
        node = next;
    }
    return rebuilt;
}

void* clientUpdateDetour(void* clientInstance, bool value) {
    void* result = g_clientUpdateOrig ? g_clientUpdateOrig(clientInstance, value) : nullptr;
    if (!clientInstance) return result;

    // Hot reload config.json roughly every 2 seconds.
    if (g_updateCounter.fetch_add(1, std::memory_order_relaxed) % 120 == 0) {
        const long long mtime = configMtime();
        if (mtime != 0 && mtime != g_configMtime.load(std::memory_order_relaxed)) {
            loadConfig();
            g_rebuildPending.store(true, std::memory_order_release);
        }
    }
    if (g_rebuildPending.exchange(false, std::memory_order_acq_rel)) {
        if (!rebuildChunks(clientInstance)) g_rebuildPending.store(true, std::memory_order_release);
    }
    return result;
}

// ---- Install -------------------------------------------------------------------------

bool hookAddress(const char* name, std::uintptr_t address, void* detour, void** original) {
    if (!address) { LOGW("signature not found: %s", name); return false; }
    if (pl::memory::hook(reinterpret_cast<void*>(address), detour, original) != 0) {
        LOGW("hook failed: %s", name);
        return false;
    }
    return true;
}

bool resolveAndInstall() {
    std::lock_guard lock(g_installMutex);
    if (g_hooksInstalled) return true;

    const std::vector<std::string> patterns{
        kSigVertex, kSigUseNewTess, kSigChunkBuild, kSigGraphicsForBlk,
        kSigSetAllDirty, kSigClientUpdate, kSigFaceUp, kSigGetTexture,
    };
    const auto found = pl::memory::resolveSignatures(patterns, kLibrary);
    auto address = [&](const char* pattern) -> std::uintptr_t {
        const auto it = found.find(std::string(pattern));
        return it == found.end() ? 0 : it->second;
    };

    g_graphicsForBlock = reinterpret_cast<GraphicsForBlockFn>(address(kSigGraphicsForBlk));
    g_setAllDirty = reinterpret_cast<SetAllDirtyFn>(address(kSigSetAllDirty));
    g_getTexture = reinterpret_cast<GetTextureFn>(address(kSigGetTexture));
    if (!g_graphicsForBlock || !g_setAllDirty || !g_getTexture) {
        LOGW("missing function: graphicsForBlock=%p setAllDirty=%p getTexture=%p",
             reinterpret_cast<void*>(g_graphicsForBlock), reinterpret_cast<void*>(g_setAllDirty),
             reinterpret_cast<void*>(g_getTexture));
        return false;
    }

    const bool ok =
        hookAddress("useNewTessellation", address(kSigUseNewTess), reinterpret_cast<void*>(useNewTessellationDetour),
                    reinterpret_cast<void**>(&g_useNewTessOrig))
        && hookAddress("tessellateFaceUp", address(kSigFaceUp), reinterpret_cast<void*>(faceUpDetour),
                       reinterpret_cast<void**>(&g_faceUpOrig))
        && hookAddress("vertex", address(kSigVertex), reinterpret_cast<void*>(vertexDetour),
                       reinterpret_cast<void**>(&g_vertexOrig))
        && hookAddress("chunkBuild", address(kSigChunkBuild), reinterpret_cast<void*>(chunkBuildDetour),
                       reinterpret_cast<void**>(&g_chunkBuildOrig))
        && hookAddress("clientUpdate", address(kSigClientUpdate), reinterpret_cast<void*>(clientUpdateDetour),
                       reinterpret_cast<void**>(&g_clientUpdateOrig));
    g_hooksInstalled = ok;
    LOGI(ok ? "hooks installed" : "hook install failed");
    return ok;
}

// ---- Lifecycle -----------------------------------------------------------------------

std::atomic_bool g_enabled{false};
void* (*g_dlopenOrig)(const char*, int) = nullptr;
thread_local bool g_inDlopenHook = false;

void activate() {
    if (!resolveAndInstall()) return;
    g_active.store(true, std::memory_order_release);
    g_rebuildPending.store(true, std::memory_order_release);
}

void* dlopenDetour(const char* filename, int flags) {
    void* handle = g_dlopenOrig ? g_dlopenOrig(filename, flags) : nullptr;
    if (handle && filename && std::strstr(filename, kLibrary) && !g_inDlopenHook) {
        g_inDlopenHook = true;
        if (g_enabled.load(std::memory_order_acquire)) activate();
        g_inDlopenHook = false;
    }
    return handle;
}

bool gameProcess() {
    FILE* file = std::fopen("/proc/self/cmdline", "r");
    if (!file) return false;
    char command[256]{};
    std::fread(command, 1, sizeof(command) - 1, file);
    std::fclose(file);
    return std::strcmp(command, "org.levimc.launcher") == 0
        || std::strcmp(command, "org.levimc.launcher:minecraft") == 0
        || std::strcmp(command, "com.mojang.minecraftpe") == 0;
}

}  // namespace

class SimpleGrassFlowerMod {
public:
    static SimpleGrassFlowerMod& instance() {
        static SimpleGrassFlowerMod mod;
        return mod;
    }

    bool load(pl::mod::ModContext& context) {
        g_configPath = context.configDir() / "config.json";
        loadConfig();
        if (!gameProcess()) return true;
        if (void* minecraft = dlopen(kLibrary, RTLD_NOW | RTLD_NOLOAD)) {
            dlclose(minecraft);
            return true;
        }
        // Game library not loaded yet: wait for it.
        void* libdl = dlopen("libdl.so", RTLD_NOW);
        void* symbol = libdl ? dlsym(libdl, "dlopen") : nullptr;
        if (symbol) {
            pl::memory::hook(symbol, reinterpret_cast<void*>(dlopenDetour), reinterpret_cast<void**>(&g_dlopenOrig));
        }
        if (libdl) dlclose(libdl);
        return true;
    }

    bool enable(pl::mod::ModContext&) {
        g_enabled.store(true, std::memory_order_release);
        if (!gameProcess()) return true;
        if (void* minecraft = dlopen(kLibrary, RTLD_NOW | RTLD_NOLOAD)) {
            dlclose(minecraft);
            activate();
        }
        return true;
    }

    bool disable(pl::mod::ModContext&) {
        g_enabled.store(false, std::memory_order_release);
        g_active.store(false, std::memory_order_release);
        g_rebuildPending.store(true, std::memory_order_release);
        return true;
    }

    bool unload(pl::mod::ModContext& context) { return disable(context); }
};

PL_REGISTER_MOD(SimpleGrassFlowerMod, SimpleGrassFlowerMod::instance())
