# SimpleFlowersGrass

Standalone native mod for [LeviLauncher](https://github.com/LiteLDev/LeviLaunchroid) (Minecraft Bedrock,
Android arm64). Mimics Java "flowery grass" packs such as *Simple Grass Flowers*.

> Status: experimental. Signatures/offsets are version specific.

## How it works

- **Rock, small flower, big flower** are transparent overlays. The terrain layer has no alpha test, so the mod
  captures the overlay quad (not drawn) and emits one small opaque quad per run of opaque pixels, sampling exactly
  those texels, `overlayLift` above the grass, vertex colors neutralized so biome tint does not apply. Masks live in
  `src/decor_masks.hpp`.

Variant per block comes from a position hash with the Java weights (rock 7, small flower 27, big flower 14 out of 1000).
Clover support has been removed.

## Resource pack

Use `SimpleFlowersGrass_RP_v3.mcpack` (personal use only: the Java pack is CC BY-NC-ND 4.0). `grass_top` must be a
plain list in this order. Do NOT convert it to weighted `variations`: the game then ignores the variant index and no
flowers appear.

| Index | Texture |
|---|---|
| 0 | `grass_top` |
| 1 | `grass_top` (placeholder, unused) |
| 2 | `grass_top` (placeholder, unused) |
| 3 | `decor/rock` |
| 4 | `decor/flower_small` |
| 5 | `decor/flower_big` |

If the mod logs `grass_top has no decoration variants` (logcat tag `SimpleFlowersGrass`), no decorations are drawn.

## Config

`config.json` in the mod's config directory (created on first run, reloaded about every 2 seconds in game):

```json
{
  "removeTopTint": false,
  "flipMask": false,
  "decorBrightness": 1.25,
  "decorChance": 1.0,
  "overlayLift": 0.02
}
```

- `removeTopTint`: also remove biome tint from the grass top itself.
- `flipMask`: set `true` if flowers/rocks look mirrored or have stray pixels.
- `decorBrightness`: brightness of the neutralized overlay (0.25 to 2.0).
- `decorChance`: multiplier for how many blocks get rock/flowers (0 disables).
- `overlayLift`: height of overlay quads above the grass (0.002 to 0.1). Raise it if flowers flicker or sink in.

## Known limits

- Biome variants (swamp, pale garden, sakura) and nylium/podzol/mycelium variants are not implemented.
- `src/decor_masks.hpp` encodes the silhouettes of the Java pack's rock and flower textures. Keep the repository private.
- Offsets and signatures target the same build as BedrockTools 1.5.12 (`1.26.6X.X`).

## Build

Requirements: Android NDK r28c, xmake, Python 3 (or use the included GitHub Actions workflow).

```sh
xmake f -y -p android -a arm64-v8a -m release --ndk=/path/to/android-ndk-r28c
xmake -y
```

## Credits

Signatures, offsets and hook approach from [BedrockTools](https://github.com/QYCottage/BedrockTools) (MIT).
Decoration idea and weights from the *Simple Grass Flowers* Java pack by 2DWisp, Bedrock port by PointyFour66164
(not included).
