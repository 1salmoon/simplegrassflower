import argparse
import json
import sys
import zipfile
from pathlib import Path

MANIFEST = {
    "type": "preload-native",
    "name": "SimpleFlowersGrass",
    "author": "YourName",
    "description": "Draws untinted clover, flowers and rocks on grass blocks, like Java flowery grass packs.",
    "version": "1.0.0",
    "entry": "libSimpleFlowersGrass.so",
    "icon": "icon.png",
    "overwrite_files": ["icon.png"],
    "overwrite_folders": [],
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--library", required=True, type=Path)
    parser.add_argument("--icon", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    for path in (args.library, args.icon):
        if not path.is_file():
            print(f"Missing file: {path}", file=sys.stderr)
            return 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    manifest = (json.dumps(MANIFEST, indent=2) + "\n").encode("utf-8")
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr("manifest.json", manifest)
        archive.write(args.library, MANIFEST["entry"])
        archive.write(args.icon, "icon.png")
    print(args.output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
