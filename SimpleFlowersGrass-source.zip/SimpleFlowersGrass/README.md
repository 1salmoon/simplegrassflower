# SimpleFlowersGrass

Standalone native mod for [LeviLauncher](https://github.com/LiteLDev/LeviLaunchroid) (Minecraft Bedrock,
Android arm64). It mimics Java "flowery grass" packs such as *Simple Grass Flowers*: random clover, flowers and
rocks are drawn on top of grass blocks **without biome tint**, while the grass underneath keeps its biome color.

> Status: experimental and untested in game. Signatures/offsets are version specific.

## How it works

The Java pack has two kinds of variants. Bedrock has no per-block random models, so the mod does both in the
chunk builder:

- **Clover and small clover** are full, opaque, grayscale tiles that replace the grass top and are tinted by the
  biome. The mod draws them instead of the normal grass top (still tinted).
- **Rock, small flower, big flower** are transparent overlays. The mod draws the normal grass top, then a second
  quad 0.005 above it with vertex colors neutralized so biome tint does not apply.

Grass cubes are forced onto the legacy tessellation path, `tessellateFaceUp` is hooked, and the texture is
requested from the game as variant 1..5 of the grass top face. The variant per block is picked from a position
hash with the Java pack's weights (about 18% of grass blocks get a variant).

## Resource pack (you provide the textures)

The Java pack is licensed CC BY-NC-ND 4.0, so its textures are **not** included here and a converted copy
must not be redistributed. Convert it for personal use:

1. Copy `bedrock-pack-template/` and give it a new UUID if you like.
2. Copy these PNGs from the Java pack
   (`assets/minecraft/textures/block/grass_block/`) into `textures/blocks/decor/` with these names:

   | Java file | Bedrock file | Variant |
   |---|---|---|
   | `grass_block_top_clover.png` | `clover.png` | 1 (replaces top, tinted) |
   | `grass_block_top_clover_small.png` | `clover_small.png` | 2 (replaces top, tinted) |
   | `grass_block_top_rock.png` | `rock.png` | 3 (overlay) |
   | `grass_block_top_flower_small.png` | `flower_small.png` | 4 (overlay) |
   | `grass_block_top_flower_big.png` | `flower_big.png` | 5 (overlay) |

3. `textures/terrain_texture.json` turns `grass_top` into a list: index 0 is vanilla grass top, 1..5 are the
   decorations. Compare the `grass_top` entry with the one in the vanilla resource pack for your game version and
   fix the key or path if they differ.
4. Import the pack and enable it on the world.

If the mod logs `grass_top has no decoration variants` (logcat tag `SimpleFlowersGrass`), the game ignored the
list and no decorations are drawn.

## Config

`config.json` in the mod's config directory (created on first run, reloaded about every 2 seconds in game):

```json
{
  "removeTopTint": false,
  "decorBrightness": 1.25,
  "decorChance": 1.0
}
```

- `removeTopTint`: also remove biome tint from the grass top itself.
- `decorBrightness`: brightness of the neutralized decoration quad (0.25 to 2.0).
- `decorChance`: multiplier for how many blocks get decorations (0 disables).

## Known limits

- Biome specific variants (swamp, pale garden, sakura) and the nylium/podzol/mycelium variants of the Java pack
  are not implemented.
- The decoration is drawn in the same mesh layer as the grass. If transparent pixels render black, the layer has
  no alpha testing and the approach needs a different layer.
- Offsets and signatures target the same build as BedrockTools 1.5.12 (`1.26.6X.X`).

## Build

Requirements: Android NDK r28c, xmake, Python 3 (or use the included GitHub Actions workflow).

```sh
xmake f -y -p android -a arm64-v8a -m release --ndk=/path/to/android-ndk-r28c
xmake -y
```

## Credits

Signatures, offsets and hook approach come from [BedrockTools](https://github.com/QYCottage/BedrockTools) (MIT).
Decoration idea and weights from the *Simple Grass Flowers* Java pack by 2DWisp (not included).
