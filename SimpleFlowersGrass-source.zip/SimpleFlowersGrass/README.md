# SimpleFlowersGrass

Standalone native mod for [LeviLauncher](https://github.com/LiteLDev/LeviLaunchroid) (Minecraft Bedrock,
Android arm64). Mimics Java "flowery grass" packs such as *Simple Grass Flowers*.

> Status: experimental. Signatures/offsets are version specific.

## Split of work

- **Clover and small clover**: done by the resource pack. `grass_top` is a weighted `variations` list, so the game
  picks clover itself and biome-tints it like vanilla grass. The mod does nothing for these.
- **Rock, small flower, big flower**: done by the mod. The terrain layer has no alpha test, so a plain overlay quad
  would show transparent pixels as opaque squares. The mod captures the overlay quad (not drawn) and emits one small
  opaque quad per run of opaque pixels, sampling exactly those texels, `overlayLift` above the grass, with vertex
  colors neutralized so biome tint does not apply. Opaque-pixel masks live in `src/decor_masks.hpp`.

Grass cubes are forced onto the legacy tessellation path, `tessellateFaceUp` is hooked, and the texture is requested
as variant 3..5 of the grass top face. Variant per block comes from a position hash with the Java weights
(rock 7, small flower 27, big flower 14 out of 1000).

## Resource pack

Use the matching pack (`SimpleFlowersGrass_RP_v2.mcpack`, personal use only: the Java pack is CC BY-NC-ND 4.0, do
not redistribute converted textures). Its `grass_top` list must keep this order:

| Index | Texture | Used by |
|---|---|---|
| 0 | `grass_top` | game |
| 1 | `grass_block_top_clover` | game (tinted) |
| 2 | `grass_block_top_clover_small` | game (tinted) |
| 3 | `decor/rock` | mod |
| 4 | `decor/flower_small` | mod |
| 5 | `decor/flower_big` | mod |

`decor/*.png` are the gray grass tile with the opaque rock/flower pixels baked in. The mod only samples those baked
pixels, and slots 3..5 have weight 1 so the game almost never picks them on its own.

If the mod logs `grass_top has no decoration variants` (logcat tag `SimpleFlowersGrass`), no flowers are drawn.

## Config

`config.json` in the mod's config directory (created on first run, reloaded about every 2 seconds in game):

```json
{
  "removeTopTint": false,
  "flipMask": false,
  "decorBrightness": 1.25,
  "decorChance": 1.0,
  "modClover": false,
  "cloverChance": 1.0,
  "overlayLift": 0.02
}
```

- `removeTopTint`: also remove biome tint from the grass top itself.
- `flipMask`: set `true` if flowers/rocks look mirrored or have stray pixels.
- `decorBrightness`: brightness of the neutralized overlay (0.25 to 2.0).
- `decorChance`: multiplier for how many blocks get rock/flowers (0 disables).
- `overlayLift`: height of overlay quads above the grass (0.002 to 0.1). Raise it if flowers flicker or sink in.
- `modClover`: fallback. If the pack's clover never shows while the mod is on, set `true` and the mod picks clover
  itself (variants 1, 2). Leave `false` normally, otherwise clover is drawn twice as often.
- `cloverChance`: multiplier for mod-picked clover, only used when `modClover` is `true`.

## Known limits

- Biome variants (swamp, pale garden, sakura) and nylium/podzol/mycelium variants are not implemented.
- `src/decor_masks.hpp` encodes the silhouettes of the Java pack's rock and flower textures. Keep the repository private.
- Offsets and signatures target the same build as BedrockTools 1.5.12 (`1.26.6X.X`).

## Build

Requirements: Android NDK r28c, xmake, Python 3 (or use the included GitHub Actions workflow).

```sh
xmake f -y -p android -a arm64-v8a -m release --ndk=/path/to/android-ndk-r28c
xmake -y
```

## Credits

Signatures, offsets and hook approach from [BedrockTools](https://github.com/QYCottage/BedrockTools) (MIT).
Decoration idea and weights from the *Simple Grass Flowers* Java pack by 2DWisp, Bedrock port by PointyFour66164
(not included).
